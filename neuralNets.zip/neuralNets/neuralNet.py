import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation


def loadTrainData():

    x1 = np.load('./gendistx.npy')
    x2 = np.load('./fakedistx.npy')

    y1 = np.load('./gendisty.npy')
    y2 = np.load('./fakedisty.npy')

    X1 = np.hstack((x1, x2))
    X2 = np.hstack((y1, y2))

    X = np.vstack((X1,X2)).T

    Y = np.array([np.ones((2000,1)), np.zeros((2000,1))]).reshape((4000,1))

    return X, Y

def loadTestData():

    X = np.loadtxt('/home/anand/part1/PRML_MP/testDTW.txt', delimiter=' ')

    return X


def buildModel(X_train, Y_train, X_test):

    batch_size = 1024
    nb_epoch = 20

    model = Sequential()
    model.add(Dense(512, input_shape=(2,)))
    model.add(Activation('sigmoid'))
    model.add(Dense(512))
    model.add(Activation('sigmoid'))
    model.add(Dense(1))
    model.add(Activation('softmax'))

    model.compile(loss='binary_crossentropy',optimizer='rmsprop',
              metrics=['accuracy'])

    model.fit(X_train, Y_train, batch_size=batch_size, nb_epoch=nb_epoch,verbose=0)

    score = model.evaluate(X_test[0], verbose=1)

    return score


if __name__ == "__main__":

    X_train, Y_train = loadTrainData()
    X_test = loadTestData()

    accuracy = buildModel(X_train, Y_train, X_test[0])

